#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include "player.h"


//a=SDL_LoadBMP("background.png");

int main ()
{  
joueur j;

minimap m;


    SDL_Surface *ecran=NULL,*a=NULL,*a2=NULL,*t=NULL;
int done=1,continuer=1;

a=IMG_Load("background3.png");
a2=SDL_LoadBMP("bac1.bmp");


	initjoueur(&j);
	

    SDL_Rect positionFond,pm;
    
  

    positionFond.x = 0;
    positionFond.y = 0;
pm.x=0;
pm.y=0;
 initminimap(&m,&j);
   

    
    SDL_Event event;

    


SDL_Init(SDL_INIT_VIDEO);


    ecran = SDL_SetVideoMode(1200, 450, 32, SDL_HWSURFACE);


SDL_WM_SetCaption("Getaway", NULL);     
    
 int d=0; int i=0; int dir=0;
while (done)
{	
 SDL_PollEvent(&event);

     if (event.type == SDL_QUIT)
		{
		  done = 0;
		}
		
                
                deplacementjoueur (&j,event,a);

		deplacementmj (&j,&m,event,a2);

		SDL_BlitSurface(a, NULL, ecran, &positionFond);
		SDL_BlitSurface(a2, NULL, ecran, &pm);
		affichermini(&m,ecran);
		afficherjoueur(&j,ecran);


		
SDL_Flip(ecran);
SDL_Delay(50);
}
           
SDL_FreeSurface(a); 
SDL_FreeSurface(t); 
SDL_Quit(); 
            
                             
return 0;

}
