
#include "player.h"




void initjoueur (joueur *j)

{
    
    j->position.x =40;//40;
    j->position.y =260;//55 ;
   
     j->im=IMG_Load("11.png");
}

void afficherjoueur(joueur *j,SDL_Surface *ecran)
{
 SDL_BlitSurface(j->im, NULL, ecran, &j->position);
}

void deplacementjoueur (joueur *j,SDL_Event event,SDL_Surface *surface)
{

Uint8 *key;
 SDL_GetTicks();
 if (event.type == SDL_KEYDOWN)
 { key=SDL_GetKeyState(NULL);
   if(key[SDLK_DOWN])
		 {

				
                         
				j->position.y +=5;

 				
                          
                         
                 }
  else if(key[SDLK_UP])
                        {
  
                         
				j->position.y -=5;


                   
                          
              
                        }
  else if(key[SDLK_RIGHT])
                        {

  
                          j->position.x +=5;
				
                                  
                   
                          
                        }
  else if(key[SDLK_LEFT])
                        {
                          j->position.x -=5;
			
                        }

  
 }

}



void initminimap(minimap *m,joueur *j)
{
m->mp.x=(j->position.x)/10;
m->mp.y=10;
m->minij=IMG_Load("col1.bmp");
}
void affichermini(minimap *m,SDL_Surface *ecran)
{
 SDL_BlitSurface(m->minij, NULL, ecran, &m->mp);
}

void deplacementmj (joueur *j,minimap *m,SDL_Event event,SDL_Surface *ecran)
{


Uint8 *key;
 SDL_GetTicks();
 if (event.type == SDL_KEYDOWN)
 { key=SDL_GetKeyState(NULL);
   if(key[SDLK_DOWN])
		 {

				
                         
			
				m->mp.y =(j->position.y)/10;
	SDL_Flip(ecran);

                          
                         
                 }
  else if(key[SDLK_UP])
                        {
    
                         
				m->mp.y =(j->position.y)/10;

                   SDL_Flip(ecran);
                          
              
                        }
  else if(key[SDLK_RIGHT])
                        {
			m->mp.x =(j->position.x)/10;
                          SDL_Flip(ecran);
                        }
  else if(key[SDLK_LEFT])
                        {
  m->mp.x =(j->position.x)/10;SDL_Flip(ecran);
                        }

  
 }

}


